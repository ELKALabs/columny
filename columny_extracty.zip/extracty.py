# Version : 1.1
# Code is on git Now !!
# This code needs a lot of revision and comments, but it works for now ;)
# Author: EL MOUNIR Kamal

import sys
import csv
import argparse
import re

class Extracty():
    args = None
    csv_reader = None

    def __init__(self):
        parser = argparse.ArgumentParser(description='Extracty v1.1')
        parser.add_argument('-e', nargs='+', type=str, help="Columns to extract, index starts from 0, supportted format :\n 1,2,3 or 1 2 3 for separate columns | single column : 1 | 4-7 for range ")
        parser.add_argument('-d', nargs='?', type=str, help="Delimeter between columns, default : ,", default=',')
        parser.add_argument('-f', nargs='?', type=str, help="Input file name")
        #parser.add_argument('-o', nargs='?', type=str, help="Output file name")
        self.args = parser.parse_args()

    def _read_from_pipe(self):
        try:
            self.csv_reader = csv.reader(sys.stdin, delimiter=self.args.d)
        except TypeError:
            print('Error: "delimiter" must be a 1-character string')
            print('"'+str(self.args.d)+'" was provided')
            exit(1)

    def read_from_stream(self):
        try:
            if self.args.f not in (None, ""):
                self.f = open(self.args.f, 'r')
                self.csv_reader = csv.reader(self.f, delimiter=self.args.d)
            elif not sys.stdin.isatty():
                self._read_from_pipe()
            else:
                print("Error: No input stream provided")
                exit(1)
        except FileNotFoundError:
            print("Error: File not found")
            exit(1)
        self.process()

    def _prepare_indexes(self, args):
        try:
            args = [int(i) for i in args]
            args = sorted(set(args))
            return args
        except ValueError:
            print('Bad type conversion')
            exit(1)

    def process(self):
        indexes, op = self._parse_indexes()
        indexes = self._prepare_indexes(indexes)
        first_column = next(iter(self.csv_reader))
        n_column = len(first_column)
        if max(indexes) > n_column - 1:
            print("Index out of bound : "+str(max(indexes)))
            exit(1)
        out_format = ''
        if op == ',' or op == None:
            out_format = ['{r[' + str(n) + ']}' for n in indexes]
            out_format = self.args.d.join(out_format)
        if op == '-':
            out_format = ['{r[' + str(n) + ']}' for n in range(indexes[0],indexes[1]+1)]
            out_format = self.args.d.join(out_format)
        print(out_format.format(r=first_column))
        for row in self.csv_reader:
            print(out_format.format(r=row))

    def _parse_indexes(self):
        # Supported
        # Format : 1,2,3
        # Format : 1
        # Format : 4-7
		# Format : 1 2 3
        op = None
        try:
            args_len = len(self.args.e)
        except TypeError:
            print("Error : -e argument not provided")
            exit(1)
        args = []
        if args_len == 1:
            arg = self.args.e[0].strip()
            # checking if we have the right format : 1,2,3
            if re.search(r'^(\d+,)(\d+(,)?)+', arg):
                args = arg.split(',')
                op = ','
            elif re.search(r'^\d+\-\d+$', arg):
                args = arg.split('-')
                op = '-'
            elif re.search(r'^\d+$', arg):
                args = [arg]
            else:
                print("Error: Unsupported extraction expression")
                exit(1)
        else:
            args = self.args.e
            op = ','
        return (args, op)





if __name__ == '__main__':
    ext = Extracty()
    ext.read_from_stream()

# space in args issue