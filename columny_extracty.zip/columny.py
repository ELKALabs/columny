# Version : 1.6
# Code is on git Now !!
# This code needs a lot of revision and comments, but it works for now ;)
# Author: EL MOUNIR Kamal
import csv
import sys
import argparse
import os.path as _path
import os
import tempfile
import time

class Colonify():
    errorStrings = {"FileNotFoundError": "Error: The file couldn't be found",
                    "InternalError": "Error: An internal error has occured", "EmptyError": "The file might be empty"}
    dict_args = None
    pipe_file = None

    def __init__(self):
        parser = argparse.ArgumentParser(description='Columny v1.6')
        parser.add_argument('-p', nargs='?', type=int, help="Padding between columns, default : 5", default=5)
        parser.add_argument('-d', nargs='?', type=str, help="Delimeter between columns, default : ,", default=',')
        parser.add_argument('-f', nargs='?', type=str, help="Input file name", required=False)
        parser.add_argument('-o', nargs='?', type=str, help="Output file name")
        self.args = parser.parse_args()
        self.dict_args = vars(self.args)

    def _openWriteStream(self, filePath):
        try:
            if not _path.isdir(filePath):
                if _path.exists(_path.dirname(filePath)):
                    return open(filePath, 'w')
                elif len(_path.dirname(filePath)) == 0:
                    print("[ File ] : " + os.getcwd() + "\\" + filePath)
                    return open(filePath, 'w')
                else:
                    print("No such directory")
                    exit(1)
            else:
                print('Cannot write to a directory')
                print('Please specify a file name')
                exit(1)
        except FileNotFoundError:
            print(self.errorStrings["FileNotFoundError"])
            exit(1)

    def read_from_stream(self):
        if self.args.f not in (None, ""):
            self.f = open(self.dict_args['f'], 'r')
            self.csv_reader = csv.reader(self.f, delimiter=self.args.d)
        elif not sys.stdin.isatty():
            self._read_from_pipe()
        else:
            print("Error: No input stream provided")
            exit(1)

    def _read_from_pipe(self):
        # A very very bad method
        self.pipe_file = tempfile.SpooledTemporaryFile(mode='w+')
        self.pipe_file.write(sys.stdin.read())
        self.pipe_file.seek(0)
        self.f = self.pipe_file
        self.csv_reader = csv.reader(self.f, delimiter=self.args.d)

    def toColumn(self):
        try:
            self.read_from_stream()
            content = self.csv_reader
            padding = self.dict_args['p']
            lengths = []
            # init output stream
            fout = False
            if self.dict_args['o'] not in (None, ''):
                fout = self._openWriteStream(self.dict_args['o'])
            else:
                fout = sys.stdout
            try:
                nColumns = len(next(iter(content)))
            except StopIteration:
                print(self.errorStrings["InternalError"] + '. ' + self.errorStrings["EmptyError"])
                exit(1)
            self.f.seek(0)
            for j,row in enumerate(content):
                lengths.append([])
                for i in range(nColumns):
                    lengths[j].append(len(row[i]))
            self.f.seek(0)
            formatString = ''
            lengths = list(zip(*lengths))
            lengths = [max(l) for l in lengths]
            for j,row in enumerate(content):
                for i in range(nColumns):
                    if i == 0:
                        formatString = '{}'
                        continue
                    currentColumn = len(row[i])
                    p = currentColumn + padding + lengths[i-1]- len(row[i - 1])
                    formatString += '{:>' + str(p) + '}'
                print(formatString.format(*row), file=fout)
                formatString = ''
            self.f.seek(0)
        except FileNotFoundError:
            print(self.errorStrings["FileNotFoundError"])
            exit(1)

def main():
    col = Colonify()
    col.toColumn()
    del col


if __name__ == "__main__":
    main()
